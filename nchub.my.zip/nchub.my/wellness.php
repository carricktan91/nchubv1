<?php
include 'config.php';
include 'includes/auth_check.php';

// --- Authorization: Only for Representatives ---
if ($_SESSION['user_role'] !== 'representative') {
    header("Location: dashboard.php");
    exit();
}
$managed_club_id = $_SESSION['managed_club_id'];

// --- Fetch Customers for the dropdown ---
$customers = [];
$customer_sql = "
    SELECT u.id, u.name, u.phone_number, u.birthday 
    FROM users u 
    JOIN customer_club_memberships m ON u.id = m.customer_id 
    WHERE m.club_id = ? 
    ORDER BY u.name ASC
";
$stmt_cust = $conn->prepare($customer_sql);
$stmt_cust->bind_param("i", $managed_club_id);
$stmt_cust->execute();
$customer_result = $stmt_cust->get_result();
if ($customer_result && $customer_result->num_rows > 0) {
    while($row = $customer_result->fetch_assoc()) {
        $customers[] = $row;
    }
}
$stmt_cust->close();

include 'includes/header.php';
?>

<div class="page-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <header class="mobile-header">
            <button id="hamburger-btn" class="hamburger-btn">&#9776;</button>
            <div class="header-title">Wellness Evaluation</div>
        </header>
        <main>
            <h1>Wellness Evaluation</h1>
            <p class="description">Input your customer's latest wellness metrics to track their progress.</p>

            <div class="card">
                <h2>Enter Customer Data</h2>
                 <?php if(isset($_GET['status']) && $_GET['status'] == 'success'): ?>
                    <p class="success-message">Wellness log saved successfully!</p>
                <?php endif; ?>
                 <?php if(isset($_GET['error'])): ?>
                    <p class="error-message">Error: <?php echo htmlspecialchars($_GET['error']); ?></p>
                <?php endif; ?>

                <form action="actions/add_wellness_action.php" method="POST" class="form-container">
                    <div class="form-group">
                        <label for="customer_id">Customer</label>
                        <select id="customer_id" name="customer_id" required onchange="updateAge(this)">
                            <option value="">-- Select a Customer --</option>
                            <?php foreach($customers as $customer): ?>
                                <option value="<?php echo $customer['id']; ?>" data-birthday="<?php echo $customer['birthday']; ?>">
                                    <?php echo htmlspecialchars($customer['name']); ?> (<?php echo htmlspecialchars($customer['phone_number'] ?: 'No Phone'); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-grid">
                        <div class="form-group">
                            <label for="log_date">Log Date</label>
                            <input type="date" id="log_date" name="log_date" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="age">Age</label>
                            <input type="text" id="age" name="age" readonly placeholder="Select a customer">
                        </div>
                        <div class="form-group">
                            <label for="height">Height (cm)</label>
                            <input type="number" step="0.1" id="height" name="height" placeholder="e.g., 175.5">
                        </div>
                        <div class="form-group">
                            <label for="weight">Weight (kg)</label>
                            <input type="number" step="0.1" id="weight" name="weight" placeholder="e.g., 70.5">
                        </div>
                        <div class="form-group">
                            <label for="fat_percentage">Fat %</label>
                            <input type="number" step="0.1" id="fat_percentage" name="fat_percentage" placeholder="e.g., 22.5">
                        </div>
                        <div class="form-group">
                            <label for="visceral_fat">Visceral Fat</label>
                            <input type="number" step="0.1" id="visceral_fat" name="visceral_fat" placeholder="e.g., 4.5">
                        </div>
                        <div class="form-group">
                            <label for="bone_mass">Bone Mass (kg)</label>
                            <input type="number" step="0.1" id="bone_mass" name="bone_mass" placeholder="e.g., 2.8">
                        </div>
                        <div class="form-group">
                            <label for="bmr">BMR (kcal)</label>
                            <input type="number" id="bmr" name="bmr" placeholder="e.g., 1500">
                        </div>
                        <div class="form-group">
                            <label for="metabolic_age">Metabolic Age</label>
                            <input type="number" id="metabolic_age" name="metabolic_age" placeholder="e.g., 25">
                        </div>
                        <div class="form-group">
                            <label for="muscle_mass">Muscle Mass (kg)</label>
                            <input type="number" step="0.1" id="muscle_mass" name="muscle_mass" placeholder="e.g., 50.2">
                        </div>
                         <div class="form-group">
                            <label for="physique_rating">Physique Rating</label>
                            <input type="number" id="physique_rating" name="physique_rating" placeholder="1-9">
                        </div>
                         <div class="form-group">
                            <label for="water_percentage">Water %</label>
                            <input type="number" step="0.1" id="water_percentage" name="water_percentage" placeholder="e.g., 55.0">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="remarks">Remarks</label>
                        <textarea id="remarks" name="remarks" rows="3"></textarea>
                    </div>

                    <button type="submit" class="btn">Save Evaluation</button>
                </form>
            </div>
        </main>
    </div>
</div>
<div class="overlay" id="overlay"></div>

<script>
function updateAge(selectElement) {
    const selectedOption = selectElement.options[selectElement.selectedIndex];
    const birthday = selectedOption.getAttribute('data-birthday');
    const ageInput = document.getElementById('age');
    
    if (birthday) {
        const birthDate = new Date(birthday);
        const today = new Date();
        let age = today.getFullYear() - birthDate.getFullYear();
        const m = today.getMonth() - birthDate.getMonth();
        if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }
        ageInput.value = age;
    } else {
        ageInput.value = 'N/A';
    }
}
</script>

<?php include 'includes/footer.php'; ?>