<?php
include 'config.php';
include 'includes/auth_check.php';

// --- Authorization: Only for Representatives ---
if ($_SESSION['user_role'] !== 'representative') {
    header("Location: dashboard.php");
    exit();
}
$managed_club_id = $_SESSION['managed_club_id'];

// --- Search Logic ---
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
$customers = [];

// --- Fetch Customers for the managed club (UPDATED to include birthday) ---
$sql = "
    SELECT u.id, u.name, u.email, u.phone_number, u.birthday, m.credit_balance 
    FROM users u
    JOIN customer_club_memberships m ON u.id = m.customer_id
    WHERE u.role = 'customer' AND m.club_id = ?
";
if (!empty($search_term)) {
    $sql .= " AND (u.name LIKE ? OR u.email LIKE ? OR u.phone_number LIKE ?)";
    $stmt = $conn->prepare($sql);
    $like_search_term = "%" . $search_term . "%";
    $stmt->bind_param("isss", $managed_club_id, $like_search_term, $like_search_term, $like_search_term);
} else {
    $sql .= " ORDER BY u.name ASC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $managed_club_id);
}

$stmt->execute();
$result = $stmt->get_result();
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $customers[] = $row;
    }
}
$stmt->close();

include 'includes/header.php';
?>

<div class="page-wrapper">
    
    <?php include 'includes/sidebar.php'; ?>

    <div class="main-content">
        <header class="mobile-header">
            <button id="hamburger-btn" class="hamburger-btn">&#9776;</button>
            <div class="header-title">Manage Customers</div>
        </header>

        <main>
            <h1>Manage Customers</h1>
            <p class="description">Add existing users to your club and view your current members.</p>

            <div class="card">
                <h2>Add Customer to Club</h2>
                 <p class="description">Enter the email of a user who has already signed up to add them to your club.</p>
                <?php if(isset($_GET['status']) && $_GET['status'] == 'customer_added'): ?>
                    <p class="success-message">Customer added to your club successfully!</p>
                <?php endif; ?>
                 <?php if(isset($_GET['error'])): ?>
                    <p class="error-message">Error: <?php echo htmlspecialchars($_GET['error']); ?></p>
                <?php endif; ?>
                <form action="actions/add_customer_action.php" method="POST" class="form-container">
                    <div class="form-group">
                        <label for="email">Customer's Email Address</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <button type="submit" class="btn">Add Customer</button>
                </form>
            </div>

            <div class="card">
                <h2>Your Club's Customers</h2>
                <form action="customers.php" method="GET" class="form-container search-form">
                    <div class="form-group">
                        <label for="search">Search Your Customers</label>
                        <input type="text" id="search" name="search" placeholder="Search by name, email, or phone..." value="<?php echo htmlspecialchars($search_term); ?>">
                    </div>
                    <button type="submit" class="btn">Search</button>
                </form>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Birthday</th> <th>Credit Balance</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($customers)): ?>
                                <tr>
                                    <td colspan="5" style="text-align: center;">No customers found for your club.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($customers as $customer): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($customer['name']); ?></td>
                                        <td><?php echo htmlspecialchars($customer['email']); ?></td>
                                        <td><?php echo htmlspecialchars($customer['phone_number'] ?: 'N/A'); ?></td>
                                        <td><?php echo $customer['birthday'] ? date('M j', strtotime($customer['birthday'])) : 'N/A'; ?></td>
                                        <td><?php echo htmlspecialchars($customer['credit_balance']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<div class="overlay" id="overlay"></div>

<?php include 'includes/footer.php'; ?>