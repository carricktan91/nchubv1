<?php
include 'config.php';
include 'includes/auth_check.php';

// --- Authorization Check ---
if ($_SESSION['user_role'] !== 'superadmin') {
    header("Location: dashboard.php");
    exit();
}

// --- Fetch all clubs for the assignment dropdown ---
$clubs = [];
$club_sql = "SELECT id, name FROM clubs WHERE status = 'active' ORDER BY name ASC";
$club_result = $conn->query($club_sql);
if ($club_result && $club_result->num_rows > 0) {
    while($row = $club_result->fetch_assoc()) {
        $clubs[] = $row;
    }
}

// --- Search Logic (Updated) ---
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
$users = [];
$sql = "SELECT id, name, email, role, created_at FROM users";

if (!empty($search_term)) {
    // UPDATED: Search by name, email, or phone number
    $sql .= " WHERE name LIKE ? OR email LIKE ? OR phone_number LIKE ?";
    $stmt = $conn->prepare($sql);
    $like_search_term = "%" . $search_term . "%";
    $stmt->bind_param("sss", $like_search_term, $like_search_term, $like_search_term);
} else {
    // Default: Get all users
    $sql .= " ORDER BY created_at DESC";
    $stmt = $conn->prepare($sql);
}

$stmt->execute();
$result = $stmt->get_result();
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $users[] = $row;
    }
}
$stmt->close();


include 'includes/header.php';
?>

<div class="page-wrapper">
    
    <?php include 'includes/sidebar.php'; ?>

    <div class="main-content">
        <header class="mobile-header">
            <button id="hamburger-btn" class="hamburger-btn">&#9776;</button>
            <div class="header-title">Manage Users</div>
        </header>

        <main>
            <h1>Manage All Users</h1>
            <p class="description">View all registered users and manage their profiles and roles.</p>
            
            <?php if(isset($_GET['status']) && $_GET['status'] == 'password_reset_success'): ?>
            <p class="success-message">User's password has been successfully reset.</p>
            <?php endif; ?>
            
            <div class="card">
                <h2>User List</h2>
                <form action="superadmin_users.php" method="GET" class="form-container search-form">
                    <div class="form-group">
                        <label for="search">Search Users</label>
                        <input type="text" id="search" name="search" placeholder="Search by name, email, or phone..." value="<?php echo htmlspecialchars($search_term); ?>">
                    </div>
                    <button type="submit" class="btn">Search</button>
                </form>

                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($users)): ?>
                                <tr>
                                    <td colspan="4" style="text-align: center;">No users found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($user['name']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td><?php echo ucfirst(htmlspecialchars($user['role'])); ?></td>
                                        <td class="action-cell">
                                            <a href="view_user_profile.php?id=<?php echo $user['id']; ?>" class="action-btn">View</a>
                                            <a href="reset_user_password.php?id=<?php echo $user['id']; ?>" class="action-btn">Reset Pass</a>
                                            <?php if ($user['role'] === 'customer'): ?>
                                                <button onclick="toggleAssignForm('<?php echo $user['id']; ?>')" class="action-btn">Assign as Rep</button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php if ($user['role'] === 'customer'): ?>
                                    <tr id="assign_form_<?php echo $user['id']; ?>" class="assign-form-row" style="display: none;">
                                        <td colspan="4">
                                            <form action="actions/assign_rep_action.php" method="POST" class="inline-form">
                                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                                <select name="club_id" required>
                                                    <option value="">-- Select Club --</option>
                                                    <?php foreach($clubs as $club): ?>
                                                        <option value="<?php echo $club['id']; ?>"><?php echo htmlspecialchars($club['name']); ?></option>
                                                    <?php endforeach; ?>
                                                </select>
                                                <button type="submit" class="btn btn-small">Confirm Assignment</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<div class="overlay" id="overlay"></div>

<script>
function toggleAssignForm(userId) {
    const formRow = document.getElementById('assign_form_' + userId);
    if (formRow) {
        // Close all other open forms first
        document.querySelectorAll('.assign-form-row').forEach(row => {
            if (row.id !== formRow.id) {
                row.style.display = 'none';
            }
        });
        // Toggle the clicked one
        formRow.style.display = formRow.style.display === 'none' ? 'table-row' : 'none';
    }
}
</script>

<?php include 'includes/footer.php'; ?>