<?php
// Include the configuration file which also starts the session
include 'config.php';

// Check if the user is already logged in by looking for the session variable
if (isset($_SESSION['user_id'])) {
    // If the user is logged in, send them directly to their dashboard
    header("Location: dashboard.php");
    exit();
} else {
    // If the user is not logged in, send them to the login page
    header("Location: login.php");
    exit();
}
?>