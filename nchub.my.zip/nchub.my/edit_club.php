<?php
include 'config.php';
include 'includes/auth_check.php';

// --- Authorization & Data Fetching ---
if ($_SESSION['user_role'] !== 'superadmin') {
    header("Location: dashboard.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid Club ID.");
}

$club_id = $_GET['id'];
$stmt = $conn->prepare("SELECT id, name, status, expiry_date, remarks FROM clubs WHERE id = ?");
$stmt->bind_param("i", $club_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    die("Club not found.");
}
$club = $result->fetch_assoc();
$stmt->close();

include 'includes/header.php';
?>

<div class="page-wrapper">
    
    <?php include 'includes/sidebar.php'; ?>

    <div class="main-content">
        <header class="mobile-header">
            <button id="hamburger-btn" class="hamburger-btn">&#9776;</button>
            <div class="header-title">Edit Club</div>
        </header>

        <main>
            <h1>Edit Club: <?php echo htmlspecialchars($club['name']); ?></h1>

            <div class="card">
                <form action="actions/edit_club_action.php" method="POST" class="form-container">
                    <input type="hidden" name="club_id" value="<?php echo $club['id']; ?>">
                    
                    <div class="form-group">
                        <label for="club_name">Club Name</label>
                        <input type="text" id="club_name" name="club_name" value="<?php echo htmlspecialchars($club['name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status">
                            <option value="active" <?php if($club['status'] == 'active') echo 'selected'; ?>>Active</option>
                            <option value="expired" <?php if($club['status'] == 'expired') echo 'selected'; ?>>Expired</option>
                            <option value="suspended" <?php if($club['status'] == 'suspended') echo 'selected'; ?>>Suspended</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="expiry_date">Expiry Date</label>
                        <input type="date" id="expiry_date" name="expiry_date" value="<?php echo htmlspecialchars($club['expiry_date']); ?>">
                    </div>

                    <div class="form-group">
                        <label for="remarks">Remarks (for Superadmin)</label>
                        <textarea id="remarks" name="remarks" rows="4"><?php echo htmlspecialchars($club['remarks']); ?></textarea>
                    </div>

                    <button type="submit" class="btn">Save Changes</button>
                    <a href="superadmin_clubs.php" style="margin-left: 1rem;">Cancel</a>
                </form>
            </div>
        </main>
    </div>
</div>

<div class="overlay" id="overlay"></div>

<?php include 'includes/footer.php'; ?>