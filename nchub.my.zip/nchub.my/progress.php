<?php
include 'config.php';
include 'includes/auth_check.php';

// --- Authorization: Allow both customers and representatives ---
if (!in_array($_SESSION['user_role'], ['customer', 'representative'])) {
    header("Location: dashboard.php");
    exit();
}

$is_customer_view = ($_SESSION['user_role'] === 'customer');
$selected_customer_id = null;
$club_context_id = null;
$customers = []; // Only used for rep view
$wellness_logs = [];
$chart_data_json = '[]';
$selected_customer_name = 'Your'; // Default text for customer view
$customer_birthday = null;

// --- Logic to determine which user and club to show ---
if ($is_customer_view) {
    // It's a CUSTOMER viewing their own progress
    $selected_customer_id = $_SESSION['user_id'];
    if (isset($_SESSION['current_club_id'])) {
        $club_context_id = $_SESSION['current_club_id'];
    }
} else {
    // It's a REPRESENTATIVE viewing a customer's progress
    $club_context_id = $_SESSION['managed_club_id'];
    // Fetch customers for the dropdown
    $customer_sql = "SELECT u.id, u.name, u.phone_number FROM users u JOIN customer_club_memberships m ON u.id = m.customer_id WHERE m.club_id = ? ORDER BY u.name ASC";
    $stmt_cust = $conn->prepare($customer_sql);
    $stmt_cust->bind_param("i", $club_context_id);
    $stmt_cust->execute();
    $customer_result = $stmt_cust->get_result();
    if ($customer_result) {
        while($row = $customer_result->fetch_assoc()) {
            $customers[] = $row;
        }
    }
    $stmt_cust->close();
    
    if (isset($_GET['customer_id'])) {
        $selected_customer_id = (int)$_GET['customer_id'];
    }
}

// --- If we have a valid user and club context, fetch their data ---
if ($selected_customer_id && $club_context_id) {
    $stmt_user = $conn->prepare("SELECT name, birthday FROM users WHERE id = ?");
    $stmt_user->bind_param("i", $selected_customer_id);
    $stmt_user->execute();
    $user_result = $stmt_user->get_result();
    if($user_result->num_rows > 0){
        $user_data = $user_result->fetch_assoc();
        if (!$is_customer_view) {
             $selected_customer_name = $user_data['name'];
        }
        $customer_birthday = $user_data['birthday'];
    }
    $stmt_user->close();

    $logs_sql = "SELECT * FROM wellness_logs WHERE customer_id = ? AND club_id = ? ORDER BY log_date ASC";
    $stmt_logs = $conn->prepare($logs_sql);
    $stmt_logs->bind_param("ii", $selected_customer_id, $club_context_id);
    $stmt_logs->execute();
    $logs_result = $stmt_logs->get_result();
    if ($logs_result) {
        while($row = $logs_result->fetch_assoc()) {
            if ($customer_birthday) {
                $birthDate = new DateTime($customer_birthday);
                $logDate = new DateTime($row['log_date']);
                $row['age_at_log'] = $logDate->diff($birthDate)->y;
            } else {
                $row['age_at_log'] = 'N/A';
            }
            $wellness_logs[] = $row;
        }
    }
    $stmt_logs->close();
    
    $chart_data_for_json = [];
    foreach ($wellness_logs as $log) {
        $log['date_formatted'] = date('M j, Y', strtotime($log['log_date']));
        $chart_data_for_json[] = $log;
    }
    $chart_data_json = json_encode($chart_data_for_json);
}

include 'includes/header.php';
?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<div class="page-wrapper">
    
    <?php include 'includes/sidebar.php'; ?>

    <div class="main-content">
        <header class="mobile-header">
            <button id="hamburger-btn" class="hamburger-btn">&#9776;</button>
            <div class="header-title">Progress</div>
        </header>

        <main>
            <h1><?php echo $is_customer_view ? 'My Progress' : 'Customer Progress'; ?></h1>
            <p class="description">View wellness data, history, and trends.</p>
            
            <?php if (!$is_customer_view): ?>
            <div class="card">
                <h2>Select Customer</h2>
                <form action="progress.php" method="GET" class="form-container">
                    <div class="form-group">
                        <label for="customer_id">Choose a customer to view their progress</label>
                        <select name="customer_id" id="customer_id" onchange="this.form.submit()">
                            <option value="">-- Select --</option>
                            <?php foreach($customers as $customer): ?>
                                <option value="<?php echo $customer['id']; ?>" <?php if($selected_customer_id == $customer['id']) echo 'selected'; ?>>
                                    <?php echo htmlspecialchars($customer['name']); ?> (<?php echo htmlspecialchars($customer['phone_number'] ?: 'No Phone'); ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </form>
            </div>
            <?php endif; ?>

            <?php if ($selected_customer_id && !empty($wellness_logs)): ?>
                <div class="card">
                    <h2>Progress Chart for <?php echo htmlspecialchars($selected_customer_name); ?></h2>
                    <div id="chart-controls" class="chart-controls">
                        <label><input type="checkbox" name="metric" value="weight" checked> Weight</label>
                        <label><input type="checkbox" name="metric" value="fat_percentage"> Fat %</label>
                        <label><input type="checkbox" name="metric" value="muscle_mass"> Muscle Mass</label>
                        <label><input type="checkbox" name="metric" value="visceral_fat"> Visceral Fat</label>
                        <label><input type="checkbox" name="metric" value="bmr"> BMR</label>
                        <label><input type="checkbox" name="metric" value="water_percentage"> Water %</label>
                    </div>
                    <canvas id="progressChart"></canvas>
                </div>

                <div class="card">
                    <h2>Wellness Data History</h2>
                    <p class="description">Latest records are on the left.</p>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Metric</th>
                                    <?php foreach (array_reverse($wellness_logs) as $log): ?>
                                        <th><?php echo date('M j, Y', strtotime($log['log_date'])); ?></th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                function render_row($label, $key, $logs) {
                                    echo "<tr><td><strong>{$label}</strong></td>";
                                    foreach (array_reverse($logs) as $log) {
                                        echo "<td>" . htmlspecialchars($log[$key] ?? '-') . "</td>";
                                    }
                                    echo "</tr>";
                                }
                                render_row('Age', 'age_at_log', $wellness_logs);
                                render_row('Weight (kg)', 'weight', $wellness_logs);
                                render_row('Height (cm)', 'height', $wellness_logs);
                                render_row('Fat %', 'fat_percentage', $wellness_logs);
                                render_row('Visceral Fat', 'visceral_fat', $wellness_logs);
                                render_row('Bone Mass (kg)', 'bone_mass', $wellness_logs);
                                render_row('BMR (kcal)', 'bmr', $wellness_logs);
                                render_row('Metabolic Age', 'metabolic_age', $wellness_logs);
                                render_row('Muscle Mass (kg)', 'muscle_mass', $wellness_logs);
                                render_row('Physique Rating', 'physique_rating', $wellness_logs);
                                render_row('Water %', 'water_percentage', $wellness_logs);
                                render_row('Total Weight Loss (kg)', 'total_weight_loss', $wellness_logs);
                                render_row('Total Fat Loss (%)', 'total_fat_loss', $wellness_logs);
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php elseif ($selected_customer_id): ?>
                 <div class="card"><p style="text-align: center;">No wellness data has been recorded for <?php echo $is_customer_view ? 'you in this club' : 'this customer'; ?>.</p></div>
            <?php elseif ($is_customer_view && !$club_context_id): ?>
                 <div class="card"><p style="text-align: center;">Please go to your dashboard and select a club to view your progress.</p></div>
            <?php endif; ?>
        </main>
    </div>
</div>
<div class="overlay" id="overlay"></div>

<script>
const progressChartCanvas = document.getElementById('progressChart');
if (progressChartCanvas) {
    const chartData = <?php echo $chart_data_json; ?>;
    const labels = chartData.map(d => d.date_formatted);

    const metricConfig = {
        weight: { label: 'Weight (kg)', borderColor: '#00A36C' },
        fat_percentage: { label: 'Fat %', borderColor: '#FF9500' },
        muscle_mass: { label: 'Muscle Mass (kg)', borderColor: '#5856D6' },
        visceral_fat: { label: 'Visceral Fat', borderColor: '#FF3B30' },
        bmr: { label: 'BMR (kcal)', borderColor: '#5AC8FA' },
        water_percentage: { label: 'Water %', borderColor: '#34C759' }
    };
    
    let chartInstance = new Chart(progressChartCanvas, {
        type: 'line',
        data: { labels: labels, datasets: [] },
        options: {
            responsive: true,
            scales: { y: { beginAtZero: false } },
            interaction: { mode: 'index', intersect: false },
            plugins: { tooltip: { position: 'nearest' } }
        }
    });

    function updateChart() {
        const selectedMetrics = Array.from(document.querySelectorAll('#chart-controls input:checked')).map(cb => cb.value);
        
        chartInstance.data.datasets = selectedMetrics.map(metric => {
            return {
                label: metricConfig[metric].label,
                data: chartData.map(d => d[metric]),
                borderColor: metricConfig[metric].borderColor,
                backgroundColor: metricConfig[metric].borderColor + '33',
                borderWidth: 2,
                tension: 0.1,
                fill: false
            };
        });
        chartInstance.update();
    }

    document.querySelectorAll('#chart-controls input[name="metric"]').forEach(checkbox => {
        checkbox.addEventListener('change', updateChart);
    });

    updateChart();
}
</script>
<?php include 'includes/footer.php'; ?>