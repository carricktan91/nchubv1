<?php
include 'config.php';
include 'includes/auth_check.php';

// --- Authorization: Only for Representatives ---
if ($_SESSION['user_role'] !== 'representative') {
    header("Location: dashboard.php");
    exit();
}
$managed_club_id = $_SESSION['managed_club_id'];

// --- Fetch all announcements for the managed club ---
$announcements = [];
$sql = "SELECT id, title, content, image_url, created_at FROM announcements WHERE club_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $managed_club_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $announcements[] = $row;
    }
}
$stmt->close();

include 'includes/header.php';
?>

<div class="page-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <header class="mobile-header">
            <button id="hamburger-btn" class="hamburger-btn">&#9776;</button>
            <div class="header-title">Announcements</div>
        </header>
        <main>
            <h1>Announcements</h1>
            <p class="description">Create and manage announcements for your club members.</p>

            <div class="card">
                <h2>Create New Announcement</h2>
                <?php if(isset($_GET['status']) && $_GET['status'] == 'success'): ?>
                    <p class="success-message">Announcement published successfully!</p>
                <?php endif; ?>
                <?php if(isset($_GET['error'])): ?>
                    <p class="error-message">Error: <?php echo htmlspecialchars($_GET['error']); ?></p>
                <?php endif; ?>
                <form action="actions/add_announcement_action.php" method="POST" class="form-container">
                    <div class="form-group">
                        <label for="title">Title</label>
                        <input type="text" id="title" name="title" required>
                    </div>
                    <div class="form-group">
                        <label for="content">Content</label>
                        <textarea id="content" name="content" rows="5" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="image_url">Image URL (Optional)</label>
                        <input type="url" id="image_url" name="image_url" placeholder="https://example.com/image.png">
                    </div>
                    <button type="submit" class="btn">Publish Announcement</button>
                </form>
            </div>

            <h2 style="margin-top: 2rem;">Published Announcements</h2>
            <div class="announcements-grid">
                <?php if (empty($announcements)): ?>
                    <p>No announcements have been published for this club yet.</p>
                <?php else: ?>
                    <?php foreach ($announcements as $announcement): ?>
                        <div class="announcement-card">
                            <?php if (!empty($announcement['image_url'])): ?>
                                <img src="<?php echo htmlspecialchars($announcement['image_url']); ?>" alt="<?php echo htmlspecialchars($announcement['title']); ?>" class="announcement-image">
                            <?php endif; ?>
                            <div class="announcement-content">
                                <h3><?php echo htmlspecialchars($announcement['title']); ?></h3>
                                <p class="announcement-date"><?php echo date('F j, Y', strtotime($announcement['created_at'])); ?></p>
                                <p><?php echo nl2br(htmlspecialchars($announcement['content'])); ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </main>
    </div>
</div>
<div class="overlay" id="overlay"></div>
<?php include 'includes/footer.php'; ?>