<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Badminton Court Charge Calculator</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        function addSlot() {
            const container = document.getElementById('slots-container');
            const slotDiv = document.createElement('div');
            slotDiv.className = 'slot-entry flex space-x-2 mb-2';
            slotDiv.innerHTML = `
                <input type="text" name="slot_names[]" placeholder="Slot (e.g., 6-7pm)" class="border rounded px-2 py-1 w-1/3" required>
                <input type="number" name="slot_rates[]" placeholder="Rate (RM)" step="0.01" min="0" class="border rounded px-2 py-1 w-1/3" required>
                <button type="button" onclick="this.parentElement.remove(); updateFriendSlots();" class="bg-red-500 text-white px-2 py-1 rounded">Remove</button>
            `;
            container.appendChild(slotDiv);
            updateFriendSlots();
        }

        function addFriend() {
            const container = document.getElementById('friends-container');
            const friendDiv = document.createElement('div');
            friendDiv.className = 'friend-entry flex flex-col mb-4';
            friendDiv.innerHTML = `
                <div class="flex space-x-2 mb-2">
                    <input type="text" name="friend_names[]" placeholder="Player's Name" class="border rounded px-2 py-1 w-1/3" required oninput="updateFriendSlots()">
                    <button type="button" onclick="this.parentElement.parentElement.remove(); updateFriendSlots();" class="bg-red-500 text-white px-2 py-1 rounded">Remove Player</button>
                </div>
                <div class="slot-checkboxes flex flex-wrap gap-2"></div>
            `;
            container.appendChild(friendDiv);
            updateFriendSlots();
        }

        function updateFriendSlots() {
            const slotNames = Array.from(document.querySelectorAll('input[name="slot_names[]"]')).map(input => input.value.trim()).filter(val => val !== '');
            const friendEntries = document.querySelectorAll('.friend-entry');
            friendEntries.forEach(entry => {
                const checkboxContainer = entry.querySelector('.slot-checkboxes');
                const friendName = entry.querySelector('input[name="friend_names[]"]').value.trim() || 'temp_' + Math.random().toString(36).substr(2, 9);
                checkboxContainer.innerHTML = '';
                slotNames.forEach((slot, index) => {
                    const checkbox = document.createElement('label');
                    checkbox.className = 'inline-flex items-center';
                    checkbox.innerHTML = `
                        <input type="checkbox" name="friend_slots[${friendName}][]" value="${slot}" class="mr-1" checked>
                        <span>${slot}</span>
                    `;
                    checkboxContainer.appendChild(checkbox);
                });
            });
        }
    </script>
</head>
<body class="bg-gray-100 p-6">
    <div class="max-w-3xl mx-auto bg-white p-6 rounded-lg shadow-md">
        <h1 class="text-2xl font-bold mb-4">Badminton Court Charge Calculator</h1>
        <p class="mb-4">Add time slots with their rates (in RM), select/unselect the slots each player played, and enter the total shuttlecock cost. All slots are checked by default; uncheck if a player didn't play. The calculator splits the court rental costs based on the number of players per slot and divides the shuttlecock cost equally among all players who played. Costs are rounded to 2 decimal places.</p>
        <p class="mb-4 text-sm text-gray-600">Assumes you paid the total rental and shuttlecock costs upfront. Include yourself as a player if you played to calculate your contribution.</p>

        <form method="post" class="space-y-6">
            <div>
                <h2 class="text-lg font-semibold mb-2">Shuttlecock Cost</h2>
                <input type="number" name="shuttlecock_cost" placeholder="Total Shuttlecock Cost (RM)" step="0.01" min="0" class="border rounded px-2 py-1 w-1/3" required>
            </div>

            <div>
                <h2 class="text-lg font-semibold mb-2">Time Slots</h2>
                <div id="slots-container" class="space-y-2">
                    <div class="slot-entry flex space-x-2 mb-2">
                        <input type="text" name="slot_names[]" placeholder="Slot (e.g., 6-7pm)" class="border rounded px-2 py-1 w-1/3" required oninput="updateFriendSlots()">
                        <input type="number" name="slot_rates[]" placeholder="Rate (RM)" step="0.01" min="0" class="border rounded px-2 py-1 w-1/3" required>
                        <button type="button" onclick="this.parentElement.remove(); updateFriendSlots();" class="bg-red-500 text-white px-2 py-1 rounded">Remove</button>
                    </div>
                </div>
                <button type="button" onclick="addSlot()" class="bg-blue-500 text-white px-4 py-2 rounded mt-2">Add Slot</button>
            </div>

            <div>
                <h2 class="text-lg font-semibold mb-2">Players</h2>
                <div id="friends-container" class="space-y-4">
                    <?php
                    // Preset list of 25 players numbered 1 to 25
                    $preset_friends = array_map(fn($i) => "Player $i", range(1, 25));
                    foreach ($preset_friends as $friend) {
                        echo '
                        <div class="friend-entry flex flex-col mb-4">
                            <div class="flex space-x-2 mb-2">
                                <input type="text" name="friend_names[]" value="' . htmlspecialchars($friend) . '" class="border rounded px-2 py-1 w-1/3" required oninput="updateFriendSlots()">
                                <button type="button" onclick="this.parentElement.parentElement.remove(); updateFriendSlots();" class="bg-red-500 text-white px-2 py-1 rounded">Remove Player</button>
                            </div>
                            <div class="slot-checkboxes flex flex-wrap gap-2"></div>
                        </div>';
                    }
                    ?>
                </div>
                <button type="button" onclick="addFriend()" class="bg-blue-500 text-white px-4 py-2 rounded mt-2">Add Player</button>
            </div>

            <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded">Calculate Shares</button>
        </form>

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Parse shuttlecock cost
            $shuttlecock_cost = (float)($_POST['shuttlecock_cost'] ?? 0);

            // Parse slots
            $slots = [];
            $slot_names = $_POST['slot_names'] ?? [];
            $slot_rates = $_POST['slot_rates'] ?? [];
            for ($i = 0; $i < count($slot_names); $i++) {
                $name = trim($slot_names[$i]);
                $rate = (float)trim($slot_rates[$i]);
                if ($name !== '' && $rate >= 0) {
                    $slots[$name] = $rate;
                }
            }

            // Parse friends and their slots
            $friends = [];
            $friend_slots = $_POST['friend_slots'] ?? [];
            foreach ($_POST['friend_names'] ?? [] as $name) {
                $name = trim($name);
                if ($name !== '') {
                    $friends[$name] = $friend_slots[$name] ?? [];
                }
            }

            // Build slot to friends list
            $slot_friends = [];
            foreach ($slots as $slot_name => $rate) {
                $slot_friends[$slot_name] = [];
            }
            foreach ($friends as $friend_name => $friend_slots) {
                foreach ($friend_slots as $slot) {
                    if (isset($slot_friends[$slot])) {
                        $slot_friends[$slot][] = $friend_name;
                    }
                }
            }

            // Calculate cost per player per slot
            $slot_cost_per_player = [];
            $total_court_cost = 0;
            foreach ($slots as $slot_name => $rate) {
                $total_court_cost += $rate;
                $num_players = count($slot_friends[$slot_name]);
                $slot_cost_per_player[$slot_name] = $num_players > 0 ? round($rate / $num_players, 2) : 0;
            }

            // Calculate shuttlecock cost per player
            $playing_friends = array_filter($friends, fn($slots) => !empty($slots));
            $num_players_total = count($playing_friends);
            $shuttlecock_cost_per_player = $num_players_total > 0 ? round($shuttlecock_cost / $num_players_total, 2) : 0;

            // Calculate each friend's total payment
            $friend_payments = [];
            $friend_court_payments = [];
            $friend_shuttlecock_payments = [];
            foreach ($friends as $friend_name => $friend_slots) {
                $court_payment = 0;
                foreach ($friend_slots as $slot) {
                    if (isset($slot_cost_per_player[$slot])) {
                        $court_payment += $slot_cost_per_player[$slot];
                    }
                }
                $friend_court_payments[$friend_name] = $court_payment;
                $shuttlecock_payment = !empty($friend_slots) ? $shuttlecock_cost_per_player : 0;
                $friend_shuttlecock_payments[$friend_name] = $shuttlecock_payment;
                $friend_payments[$friend_name] = $court_payment + $shuttlecock_payment;
            }

            // Output results
            echo '<div class="mt-8">';
            echo '<h2 class="text-lg font-semibold mb-2">Results</h2>';
            echo '<p><strong>Total Court Rental Cost:</strong> RM ' . number_format($total_court_cost, 2) . '</p>';
            echo '<p><strong>Total Shuttlecock Cost:</strong> RM ' . number_format($shuttlecock_cost, 2) . '</p>';
            echo '<p><strong>Total Cost:</strong> RM ' . number_format($total_court_cost + $shuttlecock_cost, 2) . '</p>';
            echo '<h3 class="text-md font-semibold mt-4 mb-2">Sessions</h3>';
            foreach ($slots as $slot_name => $rate) {
                $num_players = count($slot_friends[$slot_name]);
                echo '<p><strong>' . htmlspecialchars($slot_name) . '</strong>: ' . $num_players . ' players</p>';
            }
            echo '<table class="w-full border-collapse border mt-4">';
            echo '<thead><tr class="bg-gray-200"><th class="border p-2">Player</th><th class="border p-2">Court Cost</th><th class="border p-2">Shuttlecock Cost</th><th class="border p-2">Total to Pay</th></tr></thead>';
            echo '<tbody>';
            foreach ($friend_payments as $friend => $total) {
                echo '<tr>';
                echo '<td class="border p-2">' . htmlspecialchars($friend) . '</td>';
                echo '<td class="border p-2">RM ' . number_format($friend_court_payments[$friend], 2) . '</td>';
                echo '<td class="border p-2">RM ' . number_format($friend_shuttlecock_payments[$friend], 2) . '</td>';
                echo '<td class="border p-2">RM ' . number_format($total, 2) . '</td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
            echo '</div>';
        }
        ?>
    </div>
</body>
</html>