<?php
include '../config.php';
include '../includes/auth_check.php';

// Authorization Check
if ($_SESSION['user_role'] !== 'superadmin') {
    die("Access Denied.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $club_id = $_POST['club_id'];
    $club_name = trim($_POST['club_name']);
    $status = $_POST['status'];
    // Handle empty date by setting it to NULL
    $expiry_date = !empty($_POST['expiry_date']) ? $_POST['expiry_date'] : NULL;
    $remarks = trim($_POST['remarks']);

    if (!empty($club_name) && !empty($club_id)) {
        $stmt = $conn->prepare("UPDATE clubs SET name = ?, status = ?, expiry_date = ?, remarks = ? WHERE id = ?");
        // The type for expiry_date is 's' (string) because it can also be NULL
        $stmt->bind_param("ssssi", $club_name, $status, $expiry_date, $remarks, $club_id);

        if ($stmt->execute()) {
            header("Location: ../superadmin_clubs.php?status=edit_success");
        } else {
            header("Location: ../edit_club.php?id=" . $club_id . "&error=update_failed");
        }
        $stmt->close();
    } else {
        header("Location: ../edit_club.php?id=" . $club_id . "&error=name_required");
    }
    $conn->close();
    exit();
}
?>