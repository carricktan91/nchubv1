<?php
include '../config.php';
include '../includes/auth_check.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    
    // Collect and sanitize data
    $name = trim($_POST['name']);
    $phone_number = trim($_POST['phone_number']);
    $birthday = !empty($_POST['birthday']) ? $_POST['birthday'] : NULL;
    $gender = !empty($_POST['gender']) ? $_POST['gender'] : NULL;
    $address = trim($_POST['address']);

    if(empty($name)) {
        header("Location: ../profile.php?error=name_required");
        exit();
    }
    
    $stmt = $conn->prepare("UPDATE users SET name = ?, phone_number = ?, birthday = ?, gender = ?, address = ? WHERE id = ?");
    $stmt->bind_param("sssssi", $name, $phone_number, $birthday, $gender, $address, $user_id);

    if ($stmt->execute()) {
        // Also update the name in the session so it reflects immediately
        $_SESSION['user_name'] = $name;
        header("Location: ../profile.php?status=profile_updated");
    } else {
        header("Location: ../profile.php?error=update_failed");
    }
    
    $stmt->close();
    $conn->close();
    exit();
}
?>