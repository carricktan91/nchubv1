<?php
include '../config.php';
include '../includes/auth_check.php';

if ($_SESSION['user_role'] !== 'representative') {
    die("Access Denied.");
}
$managed_club_id = $_SESSION['managed_club_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $customer_id = $_POST['customer_id'];
    $type = $_POST['type'];
    $amount = (int)$_POST['amount'];
    $remarks = trim($_POST['remarks']);

    if (empty($customer_id) || empty($type) || $amount <= 0) {
        header("Location: ../credits.php?error=Invalid input.");
        exit();
    }
    
    $conn->begin_transaction();
    try {
        // Step 1: Get the membership details, locking the row for update
        $stmt_mem = $conn->prepare("SELECT id, credit_balance FROM customer_club_memberships WHERE customer_id = ? AND club_id = ? FOR UPDATE");
        $stmt_mem->bind_param("ii", $customer_id, $managed_club_id);
        $stmt_mem->execute();
        $result = $stmt_mem->get_result();

        if ($result->num_rows === 0) {
            throw new Exception("Customer is not a member of this club.");
        }
        $membership = $result->fetch_assoc();
        $membership_id = $membership['id'];
        $current_balance = $membership['credit_balance'];
        $stmt_mem->close();

        // Step 2: Calculate new balance
        $new_balance = ($type === 'issue') ? $current_balance + $amount : $current_balance - $amount;

        if ($new_balance < 0) {
            throw new Exception("This transaction would result in a negative balance.");
        }

        // Step 3: Update the balance in the memberships table
        $stmt_update = $conn->prepare("UPDATE customer_club_memberships SET credit_balance = ? WHERE id = ?");
        $stmt_update->bind_param("ii", $new_balance, $membership_id);
        $stmt_update->execute();
        $stmt_update->close();

        // Step 4: Insert the transaction log
        $stmt_log = $conn->prepare("INSERT INTO credit_transactions (membership_id, type, amount, balance_after, remarks) VALUES (?, ?, ?, ?, ?)");
        $stmt_log->bind_param("isiis", $membership_id, $type, $amount, $new_balance, $remarks);
        $stmt_log->execute();
        $stmt_log->close();

        $conn->commit();
        header("Location: ../credits.php?status=success");

    } catch (Exception $e) {
        $conn->rollback();
        header("Location: ../credits.php?error=" . urlencode($e->getMessage()));
    }
    
    $conn->close();
    exit();
}
?>