<?php
include '../config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone_number = $_POST['phone_number'];
    $password = $_POST['password'];

    // Basic validation
    if (empty($name) || empty($email) || empty($password)) {
        die("Please fill all required fields.");
    }

    // Hash the password for security
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare SQL to prevent injection
    $stmt = $conn->prepare("INSERT INTO users (name, email, phone_number, password, role) VALUES (?, ?, ?, ?, 'customer')");
    $stmt->bind_param("ssss", $name, $email, $phone_number, $hashed_password);

    if ($stmt->execute()) {
        header("Location: ../login.php?status=signup_success");
        exit();
    } else {
        // Check for duplicate email
        if ($conn->errno == 1062) {
             header("Location: ../signup.php?error=email_exists");
        } else {
             header("Location: ../signup.php?error=unknown");
        }
        exit();
    }

    $stmt->close();
    $conn->close();
}
?>