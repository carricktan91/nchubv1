<?php
// We need to include config.php to access the session
include '../config.php';

// --- Step 1: Check if the request is a POST request ---
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    // If not, redirect back with an error
    header("Location: ../dashboard.php?error=invalid_request_method");
    exit();
}

// --- Step 2: Check if the club_id was actually sent ---
if (!isset($_POST['club_id']) || !is_numeric($_POST['club_id'])) {
    // If not, redirect back with an error
    header("Location: ../dashboard.php?error=club_id_missing");
    exit();
}

// --- If all checks pass, update the session ---
$club_id = (int)$_POST['club_id'];
$_SESSION['current_club_id'] = $club_id;

// It's good practice to ensure the session is saved before redirecting
session_write_close();

// --- Step 3: Redirect back to the dashboard with a success message ---
header("Location: ../dashboard.php?status=club_switched");
exit();
?>