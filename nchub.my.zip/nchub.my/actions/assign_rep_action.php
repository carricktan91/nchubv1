<?php
include '../config.php';
include '../includes/auth_check.php';

if ($_SESSION['user_role'] !== 'superadmin') {
    die("Access Denied.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // We now receive user_id directly
    $user_id = $_POST['user_id']; 
    $club_id = $_POST['club_id'];

    if (empty($user_id) || empty($club_id)) {
        header("Location: ../superadmin_users.php?error=missing_fields");
        exit();
    }
    
    $conn->begin_transaction();
    try {
        // Step 1: Update the user's role to 'representative'
        $stmt_update = $conn->prepare("UPDATE users SET role = 'representative' WHERE id = ? AND role = 'customer'");
        $stmt_update->bind_param("i", $user_id);
        $stmt_update->execute();

        if ($stmt_update->affected_rows === 0) {
            throw new Exception("User is not a customer or does not exist.");
        }
        $stmt_update->close();
        
        // Step 2: Insert the assignment
        $stmt_assign = $conn->prepare("INSERT INTO club_representatives (user_id, club_id) VALUES (?, ?)");
        $stmt_assign->bind_param("ii", $user_id, $club_id);
        $stmt_assign->execute();
        $stmt_assign->close();
        
        $conn->commit();
        header("Location: ../superadmin_users.php?status=assign_success");

    } catch (Exception $e) {
        $conn->rollback();
        header("Location: ../superadmin_users.php?error=" . urlencode($e->getMessage()));
    }

    $conn->close();
    exit();
}
?>