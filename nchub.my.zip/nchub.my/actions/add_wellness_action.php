<?php
include '../config.php';
include '../includes/auth_check.php';

if ($_SESSION['user_role'] !== 'representative') {
    die("Access Denied.");
}
$managed_club_id = $_SESSION['managed_club_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // --- Collect all form data ---
    $customer_id = $_POST['customer_id'];
    $log_date = $_POST['log_date'];
    
    // Use the null coalescing operator to default empty inputs to NULL
    $height = !empty($_POST['height']) ? $_POST['height'] : NULL;
    $weight = !empty($_POST['weight']) ? $_POST['weight'] : NULL;
    $fat_percentage = !empty($_POST['fat_percentage']) ? $_POST['fat_percentage'] : NULL;
    $visceral_fat = !empty($_POST['visceral_fat']) ? $_POST['visceral_fat'] : NULL;
    $bone_mass = !empty($_POST['bone_mass']) ? $_POST['bone_mass'] : NULL;
    $bmr = !empty($_POST['bmr']) ? $_POST['bmr'] : NULL;
    $metabolic_age = !empty($_POST['metabolic_age']) ? $_POST['metabolic_age'] : NULL;
    $muscle_mass = !empty($_POST['muscle_mass']) ? $_POST['muscle_mass'] : NULL;
    $physique_rating = !empty($_POST['physique_rating']) ? $_POST['physique_rating'] : NULL;
    $water_percentage = !empty($_POST['water_percentage']) ? $_POST['water_percentage'] : NULL;
    $remarks = trim($_POST['remarks']);

    // --- Calculate Total Loss ---
    $total_weight_loss = 0;
    $total_fat_loss = 0;

    // Find the very first wellness log for this customer to get baseline numbers
    $stmt_first = $conn->prepare("SELECT weight, fat_percentage FROM wellness_logs WHERE customer_id = ? ORDER BY log_date ASC, id ASC LIMIT 1");
    $stmt_first->bind_param("i", $customer_id);
    $stmt_first->execute();
    $result_first = $stmt_first->get_result();

    if ($result_first->num_rows > 0) {
        $first_log = $result_first->fetch_assoc();
        if ($weight !== NULL && $first_log['weight'] !== NULL) {
            $total_weight_loss = $first_log['weight'] - $weight;
        }
        if ($fat_percentage !== NULL && $first_log['fat_percentage'] !== NULL) {
            // This calculates total percentage points lost
            $total_fat_loss = $first_log['fat_percentage'] - $fat_percentage;
        }
    }
    $stmt_first->close();

    // --- Insert into database ---
    $sql = "INSERT INTO wellness_logs (customer_id, club_id, log_date, height, weight, fat_percentage, visceral_fat, bone_mass, bmr, metabolic_age, muscle_mass, physique_rating, water_percentage, total_weight_loss, total_fat_loss, remarks) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt_insert = $conn->prepare($sql);
    $stmt_insert->bind_param(
        "iisddddiiididdds", // i=int, d=double/decimal, s=string
        $customer_id, $managed_club_id, $log_date, $height, $weight, $fat_percentage, $visceral_fat, $bone_mass, $bmr, $metabolic_age, $muscle_mass, $physique_rating, $water_percentage, $total_weight_loss, $total_fat_loss, $remarks
    );

    if ($stmt_insert->execute()) {
        header("Location: ../wellness.php?status=success");
    } else {
        header("Location: ../wellness.php?error=" . urlencode($conn->error));
    }
    
    $stmt_insert->close();
    $conn->close();
    exit();
}
?>