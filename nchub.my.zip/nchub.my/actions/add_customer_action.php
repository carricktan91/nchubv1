<?php
include '../config.php';
include '../includes/auth_check.php';

// --- Authorization ---
if ($_SESSION['user_role'] !== 'representative') {
    die("Access Denied.");
}
$managed_club_id = $_SESSION['managed_club_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);

    if (empty($email)) {
        header("Location: ../customers.php?error=Email address is required.");
        exit();
    }
    
    $conn->begin_transaction();
    try {
        // Step 1: Find the user by email
        $stmt_find = $conn->prepare("SELECT id, role FROM users WHERE email = ?");
        $stmt_find->bind_param("s", $email);
        $stmt_find->execute();
        $result = $stmt_find->get_result();

        if ($result->num_rows === 0) {
            throw new Exception("No user found with that email address. Please ask them to sign up first.");
        }
        $user = $result->fetch_assoc();
        $customer_id = $user['id'];
        $stmt_find->close();

        // Step 2: Check if they are already a member of this club
        $stmt_check = $conn->prepare("SELECT id FROM customer_club_memberships WHERE customer_id = ? AND club_id = ?");
        $stmt_check->bind_param("ii", $customer_id, $managed_club_id);
        $stmt_check->execute();
        if ($stmt_check->get_result()->num_rows > 0) {
            throw new Exception("This user is already a member of your club.");
        }
        $stmt_check->close();

        // Step 3: Add them to the representative's club
        $stmt_add = $conn->prepare("INSERT INTO customer_club_memberships (customer_id, club_id) VALUES (?, ?)");
        $stmt_add->bind_param("ii", $customer_id, $managed_club_id);
        $stmt_add->execute();
        $stmt_add->close();
        
        $conn->commit();
        header("Location: ../customers.php?status=customer_added");

    } catch (Exception $e) {
        $conn->rollback();
        header("Location: ../customers.php?error=" . urlencode($e->getMessage()));
    }
    
    $conn->close();
    exit();
}
?>