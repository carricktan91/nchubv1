<?php
include '../config.php';
include '../includes/auth_check.php';

// --- Authorization ---
if ($_SESSION['user_role'] !== 'representative') {
    die("Access Denied.");
}
$managed_club_id = $_SESSION['managed_club_id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $image_url = trim($_POST['image_url']);

    if (empty($title) || empty($content)) {
        header("Location: ../announcements.php?error=Title and content are required.");
        exit();
    }
    
    // Set image_url to NULL if it's empty
    if (empty($image_url)) {
        $image_url = NULL;
    }

    $stmt = $conn->prepare("INSERT INTO announcements (club_id, title, content, image_url) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $managed_club_id, $title, $content, $image_url);

    if ($stmt->execute()) {
        header("Location: ../announcements.php?status=success");
    } else {
        header("Location: ../announcements.php?error=database_error");
    }
    
    $stmt->close();
    $conn->close();
    exit();
}
?>