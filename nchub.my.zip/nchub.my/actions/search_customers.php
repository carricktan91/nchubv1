<?php
include '../config.php';

// --- Authorization & Security ---
header('Content-Type: application/json');
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'representative') {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}
if (!isset($_GET['q'])) {
    echo json_encode([]);
    exit();
}

// --- Database Query ---
$managed_club_id = $_SESSION['managed_club_id'];
$search_query = trim($_GET['q']);
$customers = [];

// Search by name or phone number and include their credit balance
$sql = "
    SELECT u.id, u.name, u.phone_number, m.credit_balance 
    FROM users u
    JOIN customer_club_memberships m ON u.id = m.customer_id
    WHERE m.club_id = ? AND (u.name LIKE ? OR u.phone_number LIKE ?)
    LIMIT 10
";

$stmt = $conn->prepare($sql);
$like_query = "%" . $search_query . "%";
$stmt->bind_param("iss", $managed_club_id, $like_query, $like_query);
$stmt->execute();
$result = $stmt->get_result();

if ($result) {
    while($row = $result->fetch_assoc()) {
        $customers[] = $row;
    }
}
$stmt->close();

echo json_encode($customers);
?>