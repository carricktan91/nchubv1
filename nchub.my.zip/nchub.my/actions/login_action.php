<?php
include '../config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Find the user by email
    $stmt = $conn->prepare("SELECT id, name, email, password, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $user['password'])) {
            // Check if user is a Club Representative and if their club is active
            if ($user['role'] === 'representative') {
                $rep_stmt = $conn->prepare("
                    SELECT c.status, c.expiry_date, c.id as club_id 
                    FROM clubs c
                    JOIN club_representatives cr ON c.id = cr.club_id
                    WHERE cr.user_id = ?
                ");
                $rep_stmt->bind_param("i", $user['id']);
                $rep_stmt->execute();
                $club_result = $rep_stmt->get_result();

                if ($club_result->num_rows === 1) {
                    $club = $club_result->fetch_assoc();
                    if ($club['status'] !== 'active' || ($club['expiry_date'] != null && strtotime($club['expiry_date']) < time())) {
                        header("Location: ../login.php?error=club_inactive");
                        exit();
                    }
                     $_SESSION['managed_club_id'] = $club['club_id']; // Store managed club ID
                } else {
                    header("Location: ../login.php?error=no_club_assigned");
                    exit();
                }
                $rep_stmt->close();
            }

            // Set session variables
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_role'] = $user['role'];

            // Redirect to dashboard
            header("Location: ../dashboard.php");
            exit();
        }
    }
    
    // If login fails
    header("Location: ../login.php?error=invalid_credentials");
    exit();

    $stmt->close();
    $conn->close();
}
?>