<?php
include '../config.php';
include '../includes/auth_check.php';

// Authorization Check
if ($_SESSION['user_role'] !== 'superadmin') {
    die("Access Denied.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Validation
    if (empty($new_password) || empty($confirm_password)) {
        header("Location: ../reset_user_password.php?id=" . $user_id . "&error=Passwords cannot be empty.");
        exit();
    }
    if ($new_password !== $confirm_password) {
        header("Location: ../reset_user_password.php?id=" . $user_id . "&error=Passwords do not match.");
        exit();
    }

    // Hash the new password for security
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Update the password in the database
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $hashed_password, $user_id);

    if ($stmt->execute()) {
        header("Location: ../superadmin_users.php?status=password_reset_success");
    } else {
        header("Location: ../reset_user_password.php?id=" . $user_id . "&error=Database update failed.");
    }
    
    $stmt->close();
    $conn->close();
    exit();
}
?>