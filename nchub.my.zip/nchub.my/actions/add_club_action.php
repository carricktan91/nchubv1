<?php
include '../config.php';
include '../includes/auth_check.php';

// Authorization Check
if ($_SESSION['user_role'] !== 'superadmin') {
    die("Access Denied.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $club_name = trim($_POST['club_name']);

    if (!empty($club_name)) {
        // Use prepared statements to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO clubs (name) VALUES (?)");
        $stmt->bind_param("s", $club_name);

        if ($stmt->execute()) {
            header("Location: ../superadmin_clubs.php?status=success");
        } else {
            header("Location: ../superadmin_clubs.php?error=creation_failed");
        }
        $stmt->close();
    } else {
        header("Location: ../superadmin_clubs.php?error=name_required");
    }
    $conn->close();
    exit();
}
?>