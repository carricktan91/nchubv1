<?php
// START A SESSION FOR ALL PAGES
session_start();

// DATABASE CONNECTION DETAILS
$servername = "localhost";
$username = "";     // Replace with your database username
$password = "";      // Replace with your database password
$dbname = "";    // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- NEW LINE TO FIX THE TIME ---
// Set the MySQL time zone to your local time (UTC+8) for this connection
$conn->query("SET time_zone = '+08:00'");

?>