<?php
include 'config.php';
include 'includes/auth_check.php';

// --- Get current user's data ---
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

include 'includes/header.php';
?>

<div class="page-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <header class="mobile-header">
            <button id="hamburger-btn" class="hamburger-btn">&#9776;</button>
            <div class="header-title">My Profile</div>
        </header>
        <main>
            <h1>Profile Management</h1>
            <p class="description">Manage your personal information and account settings.</p>

            <div class="card">
                <h2>Edit Your Profile</h2>
                <?php if(isset($_GET['status']) && $_GET['status'] == 'profile_updated'): ?>
                    <p class="success-message">Profile updated successfully!</p>
                <?php endif; ?>
                <form action="actions/update_profile_action.php" method="POST" class="form-container">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="name">Full Name</label>
                            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email (Cannot be changed)</label>
                            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" readonly disabled>
                        </div>
                        <div class="form-group">
                            <label for="phone_number">Phone Number</label>
                            <input type="tel" id="phone_number" name="phone_number" value="<?php echo htmlspecialchars($user['phone_number']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="birthday">Birthday</label>
                            <input type="date" id="birthday" name="birthday" value="<?php echo htmlspecialchars($user['birthday']); ?>">
                        </div>
                         <div class="form-group">
                            <label for="gender">Gender</label>
                            <select id="gender" name="gender">
                                <option value="">-- Select --</option>
                                <option value="male" <?php if($user['gender'] == 'male') echo 'selected'; ?>>Male</option>
                                <option value="female" <?php if($user['gender'] == 'female') echo 'selected'; ?>>Female</option>
                                <option value="other" <?php if($user['gender'] == 'other') echo 'selected'; ?>>Other</option>
                                <option value="prefer_not_to_say" <?php if($user['gender'] == 'prefer_not_to_say') echo 'selected'; ?>>Prefer not to say</option>
                            </select>
                        </div>
                         <div class="form-group">
                            <label for="address">Address</label>
                            <textarea id="address" name="address" rows="3"><?php echo htmlspecialchars($user['address']); ?></textarea>
                        </div>
                    </div>
                    <button type="submit" class="btn">Save Profile Changes</button>
                </form>
            </div>

            <div class="card">
                <h2>Change Password</h2>
                 <?php if(isset($_GET['status']) && $_GET['status'] == 'password_changed'): ?>
                    <p class="success-message">Password changed successfully!</p>
                <?php endif; ?>
                <?php if(isset($_GET['error'])): ?>
                    <p class="error-message">Error: <?php echo htmlspecialchars($_GET['error']); ?></p>
                <?php endif; ?>
                <form action="actions/change_password_action.php" method="POST" class="form-container">
                    <div class="form-group">
                        <label for="current_password">Current Password</label>
                        <input type="password" id="current_password" name="current_password" required>
                    </div>
                    <div class="form-group">
                        <label for="new_password">New Password</label>
                        <input type="password" id="new_password" name="new_password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_new_password">Confirm New Password</label>
                        <input type="password" id="confirm_new_password" name="confirm_new_password" required>
                    </div>
                    <button type="submit" class="btn">Update Password</button>
                </form>
            </div>
        </main>
    </div>
</div>
<div class="overlay" id="overlay"></div>
<?php include 'includes/footer.php'; ?>