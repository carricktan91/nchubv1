<?php
include 'config.php';
include 'includes/auth_check.php';

// --- Authorization & Data Fetching ---
if ($_SESSION['user_role'] !== 'superadmin') {
    header("Location: dashboard.php");
    exit();
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    die("Invalid User ID.");
}

$user_id = $_GET['id'];

// Get the main user details first
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows === 0) {
    die("User not found.");
}
$user = $result->fetch_assoc();
$stmt->close();

// --- NEW: Role-specific data fetching ---
$memberships = [];
$assigned_club = null;

if ($user['role'] === 'customer') {
    // If the user is a customer, get their club memberships
    $membership_sql = "
        SELECT c.name, c.status, m.credit_balance 
        FROM clubs c 
        JOIN customer_club_memberships m ON c.id = m.club_id 
        WHERE m.customer_id = ?
        ORDER BY c.name ASC
    ";
    $stmt_clubs = $conn->prepare($membership_sql);
    $stmt_clubs->bind_param("i", $user_id);
    $stmt_clubs->execute();
    $clubs_result = $stmt_clubs->get_result();
    if ($clubs_result) {
        while($row = $clubs_result->fetch_assoc()) {
            $memberships[] = $row;
        }
    }
    $stmt_clubs->close();
} elseif ($user['role'] === 'representative') {
    // If the user is a representative, get their assigned club
    $rep_sql = "
        SELECT c.id, c.name, c.status 
        FROM clubs c 
        JOIN club_representatives cr ON c.id = cr.club_id 
        WHERE cr.user_id = ?
    ";
    $stmt_rep = $conn->prepare($rep_sql);
    $stmt_rep->bind_param("i", $user_id);
    $stmt_rep->execute();
    $rep_result = $stmt_rep->get_result();
    if ($rep_result) {
        $assigned_club = $rep_result->fetch_assoc();
    }
    $stmt_rep->close();
}


include 'includes/header.php';
?>

<div class="page-wrapper">
    
    <?php include 'includes/sidebar.php'; ?>

    <div class="main-content">
        <header class="mobile-header">
            <button id="hamburger-btn" class="hamburger-btn">&#9776;</button>
            <div class="header-title">View Profile</div>
        </header>

        <main>
            <h1>View Profile: <?php echo htmlspecialchars($user['name']); ?></h1>
            
            <div class="card">
                <h2>User Details</h2>
                <div class="profile-details-grid">
                    <p><strong>Name:</strong> <?php echo htmlspecialchars($user['name']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
                    <p><strong>Phone:</strong> <?php echo htmlspecialchars($user['phone_number'] ?: 'N/A'); ?></p>
                    <p><strong>Role:</strong> <?php echo ucfirst(htmlspecialchars($user['role'])); ?></p>
                    <p><strong>Birthday:</strong> <?php echo $user['birthday'] ? date('M j, Y', strtotime($user['birthday'])) : 'N/A'; ?></p>
                    <p><strong>Gender:</strong> <?php echo ucfirst(htmlspecialchars($user['gender'] ?: 'N/A')); ?></p>
                    <p><strong>Address:</strong> <?php echo htmlspecialchars($user['address'] ?: 'N/A'); ?></p>
                </div>
            </div>

            <?php if ($user['role'] === 'customer'): ?>
                <div class="card">
                    <h2>Club Memberships</h2>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Club Name</th>
                                    <th>Club Status</th>
                                    <th>Credit Balance</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($memberships)): ?>
                                    <tr><td colspan="3" style="text-align: center;">This user is not a member of any clubs.</td></tr>
                                <?php else: ?>
                                    <?php foreach ($memberships as $membership): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($membership['name']); ?></td>
                                            <td><span class="status-badge status-<?php echo htmlspecialchars($membership['status']); ?>"><?php echo ucfirst(htmlspecialchars($membership['status'])); ?></span></td>
                                            <td><?php echo htmlspecialchars($membership['credit_balance']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php elseif ($user['role'] === 'representative'): ?>
                <div class="card">
                    <h2>Club Assignment</h2>
                    <?php if ($assigned_club): ?>
                        <p>This representative is assigned to manage <strong><?php echo htmlspecialchars($assigned_club['name']); ?></strong>.</p>
                    <?php else: ?>
                        <p>This representative is not currently assigned to any club.</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <a href="superadmin_users.php" style="margin-top: 2rem; display: inline-block;">&larr; Back to User List</a>
        </main>
    </div>
</div>

<div class="overlay" id="overlay"></div>

<?php include 'includes/footer.php'; ?>