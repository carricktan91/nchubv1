<?php
include 'config.php';
include 'includes/auth_check.php';

// --- Authorization Check ---
if ($_SESSION['user_role'] !== 'superadmin') {
    header("Location: dashboard.php");
    exit();
}

// --- Search Logic ---
$search_term = '';
if (isset($_GET['search'])) {
    $search_term = trim($_GET['search']);
}

// --- Fetch Clubs with Search ---
$clubs = [];
if (!empty($search_term)) {
    // If there is a search term, filter by it
    $sql = "SELECT id, name, status, expiry_date FROM clubs WHERE name LIKE ? ORDER BY name ASC";
    $stmt = $conn->prepare($sql);
    $like_search_term = "%" . $search_term . "%";
    $stmt->bind_param("s", $like_search_term);
} else {
    // Otherwise, get all clubs
    $sql = "SELECT id, name, status, expiry_date FROM clubs ORDER BY name ASC";
    $stmt = $conn->prepare($sql);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $clubs[] = $row;
    }
}
$stmt->close();

include 'includes/header.php';
?>

<div class="page-wrapper">
    
    <?php include 'includes/sidebar.php'; ?>

    <div class="main-content">
        <header class="mobile-header">
            <button id="hamburger-btn" class="hamburger-btn">&#9776;</button>
            <div class="header-title">Manage Clubs</div>
        </header>

        <main>
            <h1>Manage Clubs</h1>
            <p class="description">Create new clubs and manage existing ones.</p>

            <div class="card">
                <h2>Create New Club</h2>
                <form action="actions/add_club_action.php" method="POST" class="form-container">
                    <div class="form-group">
                        <label for="club_name">Club Name</label>
                        <input type="text" id="club_name" name="club_name" required placeholder="e.g., NC Downtown Branch">
                    </div>
                    <button type="submit" class="btn">Create Club</button>
                </form>
            </div>

            <div class="card">
                <h2>Existing Clubs</h2>
                <form action="superadmin_clubs.php" method="GET" class="form-container search-form">
                    <div class="form-group">
                        <label for="search">Search Clubs</label>
                        <input type="text" id="search" name="search" placeholder="Enter club name to search..." value="<?php echo htmlspecialchars($search_term); ?>">
                    </div>
                    <button type="submit" class="btn">Search</button>
                </form>
                
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Club Name</th>
                                <th>Status</th>
                                <th>Expiry Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($clubs)): ?>
                                <tr>
                                    <td colspan="4" style="text-align: center;">No clubs found.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($clubs as $club): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($club['name']); ?></td>
                                        <td><span class="status-badge status-<?php echo htmlspecialchars($club['status']); ?>"><?php echo ucfirst(htmlspecialchars($club['status'])); ?></span></td>
                                        <td><?php echo $club['expiry_date'] ? date('M j, Y', strtotime($club['expiry_date'])) : 'N/A'; ?></td>
                                        <td>
                                            <a href="edit_club.php?id=<?php echo $club['id']; ?>" class="action-btn">Edit</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<div class="overlay" id="overlay"></div>

<?php include 'includes/footer.php'; ?>