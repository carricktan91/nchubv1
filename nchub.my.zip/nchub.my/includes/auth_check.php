<?php
// This script is included on every protected page.
// It checks if the user session exists.
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>