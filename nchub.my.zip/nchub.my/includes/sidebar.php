<aside class="sidebar">
    <div class="logo">
        NC Hub
    </div>
    <nav>
        <ul>
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="profile.php">Profile</a></li>
            
            <?php if ($_SESSION['user_role'] === 'customer') : ?>
                <li><a href="progress.php">My Progress</a></li>
                <li><a href="transactions.php">My Transactions</a></li>
            <?php endif; ?>

            <?php if ($_SESSION['user_role'] === 'representative') : ?>
                <li><a href="customers.php">Customers</a></li>
                <li><a href="credits.php">Credits</a></li>
                <li><a href="wellness.php">Wellness Eval</a></li>
                <li><a href="progress.php">Progress</a></li>
                <li><a href="announcements.php">Announcements</a></li>
            <?php endif; ?>

            <?php if ($_SESSION['user_role'] === 'superadmin') : ?>
                <li><a href="superadmin_users.php">Manage All Users</a></li>
                <li><a href="superadmin_clubs.php">Manage Clubs</a></li>
            <?php endif; ?>
        </ul>
    </nav>
    <div class="sidebar-footer">
        <a href="actions/logout_action.php">Logout</a>
    </div>
</aside>