<?php
include 'config.php';
include 'includes/auth_check.php';

// --- Authorization: Only for Customers ---
if ($_SESSION['user_role'] !== 'customer') {
    header("Location: dashboard.php");
    exit();
}

$customer_id = $_SESSION['user_id'];
$transactions = [];
$current_club_name = 'your'; // Default

// --- Check if a club is selected in the session ---
if (isset($_SESSION['current_club_id'])) {
    $current_club_id = $_SESSION['current_club_id'];

    // Get current club's name
    $club_stmt = $conn->prepare("SELECT name FROM clubs WHERE id = ?");
    $club_stmt->bind_param("i", $current_club_id);
    $club_stmt->execute();
    $club_result = $club_stmt->get_result();
    if ($club_data = $club_result->fetch_assoc()) {
        $current_club_name = $club_data['name'];
    }
    $club_stmt->close();
    
    // Fetch transaction history for the customer in the selected club
    $trans_sql = "
        SELECT t.transaction_date, t.type, t.amount, t.balance_after, t.remarks 
        FROM credit_transactions t
        JOIN customer_club_memberships m ON t.membership_id = m.id
        WHERE m.customer_id = ? AND m.club_id = ?
        ORDER BY t.transaction_date DESC
    ";
    $stmt_trans = $conn->prepare($trans_sql);
    $stmt_trans->bind_param("ii", $customer_id, $current_club_id);
    $stmt_trans->execute();
    $trans_result = $stmt_trans->get_result();
    if ($trans_result) {
        while($row = $trans_result->fetch_assoc()) {
            $transactions[] = $row;
        }
    }
    $stmt_trans->close();
}

include 'includes/header.php';
?>

<div class="page-wrapper">
    
    <?php include 'includes/sidebar.php'; ?>

    <div class="main-content">
        <header class="mobile-header">
            <button id="hamburger-btn" class="hamburger-btn">&#9776;</button>
            <div class="header-title">My Transactions</div>
        </header>

        <main>
            <h1>My Transaction History</h1>
            <p class="description">Showing your transaction history for <strong><?php echo htmlspecialchars($current_club_name); ?> Club</strong>.</p>
            
            <div class="card">
                <h2>History Log</h2>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Amount (Cups)</th>
                                <th>Balance After</th>
                                <th>Remarks</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($transactions)): ?>
                                <tr>
                                    <td colspan="5" style="text-align: center;">
                                        <?php echo isset($_SESSION['current_club_id']) ? 'No transactions found for this club.' : 'Please select a club from your dashboard to see your history.'; ?>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($transactions as $t): ?>
                                <tr>
                                    <td><?php echo date('M j, Y, g:ia', strtotime($t['transaction_date'])); ?></td>
                                    <td>
                                        <span class="status-badge status-<?php echo $t['type'] === 'issue' ? 'active' : 'expired'; ?>">
                                            <?php echo ucfirst($t['type']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo $t['amount']; ?></td>
                                    <td><?php echo $t['balance_after']; ?></td>
                                    <td><?php echo htmlspecialchars($t['remarks'] ?: '-'); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</div>

<div class="overlay" id="overlay"></div>

<?php include 'includes/footer.php'; ?>