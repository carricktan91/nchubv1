<?php include 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - NC Hub</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
     <div class="auth-container">
        <h2>NC Hub Login</h2>
        <?php if(isset($_GET['error'])): ?>
            <p class="error-message">Login failed: <?php echo htmlspecialchars($_GET['error']); ?></p>
        <?php endif; ?>
        <?php if(isset($_GET['status']) && $_GET['status'] == 'signup_success'): ?>
            <p class="success-message">Signup successful! Please log in.</p>
        <?php endif; ?>
        <form action="actions/login_action.php" method="post">
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">Login</button>
        </form>
         <p>Don't have an account? <a href="signup.php">Sign up here</a>.</p>
    </div>
</body>
</html>