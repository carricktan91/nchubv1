<?php 
include 'config.php';
include 'includes/auth_check.php';

// --- Page-Specific Logic ---
$user_role = $_SESSION['user_role'];
$is_customer_view = ($user_role === 'customer');
$is_rep_view = ($user_role === 'representative');

// Variables for Customer View
$memberships = [];
$current_club_name = '';
$current_balance = 0;
$announcements = [];

// Variables for Representative View
$total_customers = 0;
$total_club_balance = 0;
$birthdays_this_month = [];
$birthdays_next_month = [];


if ($is_customer_view) {
    // --- Logic for CUSTOMER dashboard ---
    $customer_id = $_SESSION['user_id'];
    
    // Fetch all club memberships for the switcher
    $membership_sql = "SELECT c.id, c.name FROM clubs c JOIN customer_club_memberships m ON c.id = m.club_id WHERE m.customer_id = ?";
    $stmt_m = $conn->prepare($membership_sql);
    $stmt_m->bind_param("i", $customer_id);
    $stmt_m->execute();
    $memberships_result = $stmt_m->get_result();
    while($membership = $memberships_result->fetch_assoc()) {
        $memberships[] = $membership;
    }
    $stmt_m->close();

    // Default to first club if none is selected
    if (!isset($_SESSION['current_club_id']) && !empty($memberships)) {
        $_SESSION['current_club_id'] = $memberships[0]['id'];
    }

    // Now, if a club is selected, fetch its details
    if (isset($_SESSION['current_club_id'])) {
        $current_club_id = $_SESSION['current_club_id'];

        // Get current club's name and customer's credit balance
        $balance_sql = "SELECT c.name, m.credit_balance FROM clubs c JOIN customer_club_memberships m ON c.id = m.club_id WHERE m.customer_id = ? AND m.club_id = ?";
        $stmt_b = $conn->prepare($balance_sql);
        $stmt_b->bind_param("ii", $customer_id, $current_club_id);
        $stmt_b->execute();
        $balance_result = $stmt_b->get_result();
        if ($balance_data = $balance_result->fetch_assoc()) {
            $current_club_name = $balance_data['name'];
            $current_balance = $balance_data['credit_balance'];
        }
        $stmt_b->close();

        // Get announcements for the current club
        $announcement_sql = "SELECT title, content, image_url, created_at FROM announcements WHERE club_id = ? ORDER BY created_at DESC LIMIT 3";
        $stmt_a = $conn->prepare($announcement_sql);
        $stmt_a->bind_param("i", $current_club_id);
        $stmt_a->execute();
        $announcement_result = $stmt_a->get_result();
        while($announcement = $announcement_result->fetch_assoc()) {
            $announcements[] = $announcement;
        }
        $stmt_a->close();
    }

} elseif ($is_rep_view) {
    // --- Logic for REPRESENTATIVE dashboard ---
    $managed_club_id = $_SESSION['managed_club_id'];

    // Get overview stats
    $stats_sql = "SELECT COUNT(id) as customer_count, SUM(credit_balance) as total_balance FROM customer_club_memberships WHERE club_id = ?";
    $stmt_stats = $conn->prepare($stats_sql);
    $stmt_stats->bind_param("i", $managed_club_id);
    $stmt_stats->execute();
    $stats_result = $stmt_stats->get_result();
    if ($stats_data = $stats_result->fetch_assoc()) {
        $total_customers = $stats_data['customer_count'] ?? 0;
        $total_club_balance = $stats_data['total_balance'] ?? 0;
    }
    $stmt_stats->close();

    // Get birthdays for this month
    $this_month_sql = "SELECT u.name, u.birthday FROM users u JOIN customer_club_memberships m ON u.id = m.customer_id WHERE m.club_id = ? AND MONTH(u.birthday) = MONTH(CURDATE()) ORDER BY DAY(u.birthday) ASC";
    $stmt_this = $conn->prepare($this_month_sql);
    $stmt_this->bind_param("i", $managed_club_id);
    $stmt_this->execute();
    $result_this = $stmt_this->get_result();
    while($row = $result_this->fetch_assoc()) {
        $birthdays_this_month[] = $row;
    }
    $stmt_this->close();

    // Get birthdays for next month
    $next_month_sql = "SELECT u.name, u.birthday FROM users u JOIN customer_club_memberships m ON u.id = m.customer_id WHERE m.club_id = ? AND MONTH(u.birthday) = MONTH(CURDATE() + INTERVAL 1 MONTH) ORDER BY DAY(u.birthday) ASC";
    $stmt_next = $conn->prepare($next_month_sql);
    $stmt_next->bind_param("i", $managed_club_id);
    $stmt_next->execute();
    $result_next = $stmt_next->get_result();
    while($row = $result_next->fetch_assoc()) {
        $birthdays_next_month[] = $row;
    }
    $stmt_next->close();
}


include 'includes/header.php';
?>

<div class="page-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <header class="mobile-header">
            <button id="hamburger-btn" class="hamburger-btn">&#9776;</button>
            <div class="header-title">Dashboard</div>
        </header>
        <main>
            <h1>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</h1>
            
            <?php if ($is_customer_view): ?>
                <p>You are currently viewing: <strong><?php echo htmlspecialchars($current_club_name ?: 'No Club Selected'); ?></strong></p>
                
                <div class="card">
                    <h2>Switch Club</h2>
                    <p class="description">Select a club to view its announcements and your progress.</p>
                    <form action="actions/switch_club_action.php" method="POST" class="form-container">
                        <div class="form-group">
                            <label for="club_switcher_select">Your Clubs</label>
                            <select name="club_id" id="club_switcher_select" onchange="this.form.submit()">
                                <?php if (empty($memberships)): ?>
                                    <option>You are not a member of any club.</option>
                                <?php else: ?>
                                    <?php foreach($memberships as $membership): ?>
                                    <option value="<?php echo $membership['id']; ?>" <?php if(isset($_SESSION['current_club_id']) && $_SESSION['current_club_id'] == $membership['id']) echo 'selected'; ?>>
                                        <?php echo htmlspecialchars($membership['name']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    </form>
                </div>
                
                <div class="overview-grid">
                    <div class="overview-card">
                        <h3>Remaining Cups</h3>
                        <p class="overview-value"><?php echo $current_balance; ?></p>
                    </div>
                </div>

                <h2 style="margin-top: 2rem;">Latest Announcements</h2>
                <div class="announcements-grid">
                    <?php if (empty($announcements)): ?>
                        <p>No announcements from this club at the moment.</p>
                    <?php else: ?>
                        <?php foreach ($announcements as $announcement): ?>
                            <div class="announcement-card">
                                <?php if (!empty($announcement['image_url'])): ?>
                                    <img src="<?php echo htmlspecialchars($announcement['image_url']); ?>" alt="<?php echo htmlspecialchars($announcement['title']); ?>" class="announcement-image">
                                <?php endif; ?>
                                <div class="announcement-content">
                                    <h3><?php echo htmlspecialchars($announcement['title']); ?></h3>
                                    <p class="announcement-date"><?php echo date('F j, Y', strtotime($announcement['created_at'])); ?></p>
                                    <p><?php echo nl2br(htmlspecialchars($announcement['content'])); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

            <?php elseif ($is_rep_view): ?>
                <p>Here's an overview of your club's activity.</p>
                <div class="overview-grid">
                    <div class="overview-card">
                        <h3>Total Customers</h3>
                        <p class="overview-value"><?php echo $total_customers; ?></p>
                    </div>
                    <div class="overview-card">
                        <h3>Total Club Balance (Cups)</h3>
                        <p class="overview-value"><?php echo number_format($total_club_balance); ?></p>
                    </div>
                </div>

                <div class="card">
                    <h2>Upcoming Birthdays</h2>
                    <div class="birthday-section">
                        <h3>This Month (<?php echo date('F'); ?>)</h3>
                        <ul class="birthday-list">
                            <?php if(empty($birthdays_this_month)): ?>
                                <li>No birthdays this month.</li>
                            <?php else: ?>
                                <?php foreach($birthdays_this_month as $bday): ?>
                                    <li><strong><?php echo date('M j', strtotime($bday['birthday'])); ?></strong> - <?php echo htmlspecialchars($bday['name']); ?></li>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                    <div class="birthday-section">
                        <h3>Next Month (<?php echo date('F', strtotime('+1 month')); ?>)</h3>
                        <ul class="birthday-list">
                             <?php if(empty($birthdays_next_month)): ?>
                                <li>No birthdays next month.</li>
                            <?php else: ?>
                                <?php foreach($birthdays_next_month as $bday): ?>
                                    <li><strong><?php echo date('M j', strtotime($bday['birthday'])); ?></strong> - <?php echo htmlspecialchars($bday['name']); ?></li>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>

            <?php else: ?>
                <p>Welcome to the Superadmin dashboard. Please use the sidebar to manage clubs and users.</p>
            <?php endif; ?>

        </main>
    </div>
</div>
<div class="overlay" id="overlay"></div>
<?php include 'includes/footer.php'; ?>