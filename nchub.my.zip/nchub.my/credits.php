<?php
include 'config.php';
include 'includes/auth_check.php';

// Authorization & Fetching Transaction History
if ($_SESSION['user_role'] !== 'representative') {
    header("Location: dashboard.php");
    exit();
}
$managed_club_id = $_SESSION['managed_club_id'];
$search_term = isset($_GET['search']) ? trim($_GET['search']) : '';
$transactions = [];

$trans_sql = "
    SELECT t.transaction_date, u.name AS customer_name, t.type, t.amount, t.balance_after, t.remarks 
    FROM credit_transactions t
    JOIN customer_club_memberships m ON t.membership_id = m.id
    JOIN users u ON m.customer_id = u.id
    WHERE m.club_id = ?
";
if (!empty($search_term)) {
    $trans_sql .= " AND (u.name LIKE ? OR t.remarks LIKE ?)";
    $stmt_trans = $conn->prepare($trans_sql);
    $like_search_term = "%" . $search_term . "%";
    $stmt_trans->bind_param("iss", $managed_club_id, $like_search_term, $like_search_term);
} else {
    $trans_sql .= " ORDER BY t.transaction_date DESC";
    $stmt_trans = $conn->prepare($trans_sql);
    $stmt_trans->bind_param("i", $managed_club_id);
}
$stmt_trans->execute();
$trans_result = $stmt_trans->get_result();
if ($trans_result) {
    while($row = $trans_result->fetch_assoc()) {
        $transactions[] = $row;
    }
}
$stmt_trans->close();

include 'includes/header.php';
?>

<div class="page-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <header class="mobile-header">
            <button id="hamburger-btn" class="hamburger-btn">&#9776;</button>
            <div class="header-title">Credit Transactions</div>
        </header>
        <main>
            <h1>Credit Transactions</h1>
            <p class="description">Record and view credit activities for your customers.</p>
            
            <div class="tabs-container">
                <div class="tabs">
                    <button class="tab-link" onclick="openTab(event, 'Record')">Record Transaction</button>
                    <button class="tab-link" onclick="openTab(event, 'History')">View History</button>
                </div>

                <div id="Record" class="tab-content">
                    <div class="card">
                        <h2>New Credit Transaction</h2>
                        <form action="actions/add_credit_transaction_action.php" method="POST" class="form-container">
                            <div class="form-group">
                                <label for="customer_search">Search for Customer (by Name or Phone)</label>
                                <input type="text" id="customer_search" autocomplete="off" placeholder="Start typing...">
                                <div id="search_results" class="ajax-results"></div>
                                <input type="hidden" name="customer_id" id="selected_customer_id" required>
                                <div id="customer_selection_display" class="selection-display" style="display: none;"></div>
                            </div>
                            <div class="form-group">
                                <label for="type">Transaction Type</label>
                                <select id="type" name="type" required>
                                    <option value="deduct">Deduct</option>
                                    <option value="issue">Issue</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="amount">Amount (Cups)</label>
                                <input type="number" id="amount" name="amount" required min="1">
                            </div>
                            <div class="form-group">
                                <label for="remarks">Remarks (Optional)</label>
                                <textarea id="remarks" name="remarks" rows="3"></textarea>
                            </div>
                            <button type="submit" class="btn">Submit Transaction</button>
                        </form>
                    </div>
                </div>

                <div id="History" class="tab-content">
                    <div class="card">
                        <h2>Transaction History</h2>
                        <form action="credits.php" method="GET" class="form-container search-form">
                            <input type="hidden" name="tab" value="History">
                            <div class="form-group">
                                <label for="search">Search History</label>
                                <input type="text" id="search" name="search" placeholder="Search by customer name or remarks..." value="<?php echo htmlspecialchars($search_term); ?>">
                            </div>
                            <button type="submit" class="btn">Search</button>
                        </form>
                        <div class="table-container">
                            <table>
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Customer</th>
                                        <th>Type</th>
                                        <th>Amount</th>
                                        <th>Balance After</th>
                                        <th>Remarks</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($transactions)): ?>
                                        <tr><td colspan="6" style="text-align: center;">No transactions found.</td></tr>
                                    <?php else: ?>
                                        <?php foreach ($transactions as $t): ?>
                                        <tr>
                                            <td><?php echo date('M j, Y, g:ia', strtotime($t['transaction_date'])); ?></td>
                                            <td><?php echo htmlspecialchars($t['customer_name']); ?></td>
                                            <td><span class="status-badge status-<?php echo $t['type'] === 'issue' ? 'active' : 'expired'; ?>"><?php echo ucfirst($t['type']); ?></span></td>
                                            <td><?php echo $t['amount']; ?></td>
                                            <td><?php echo $t['balance_after']; ?></td>
                                            <td><?php echo htmlspecialchars($t['remarks'] ?: '-'); ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</div>
<div class="overlay" id="overlay"></div>

<script>
// --- Tab Switcher Logic ---
function openTab(evt, tabName) {
    let i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tab-content");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tab-link");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(tabName).style.display = "block";
    if (evt) {
        evt.currentTarget.className += " active";
    } else {
        // For page load
        for (i = 0; i < tablinks.length; i++) {
            if (tablinks[i].textContent === tabName) {
                tablinks[i].className += " active";
                break;
            }
        }
    }
}

// On page load, check for a tab parameter to open the correct tab
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const tab = urlParams.get('tab') || 'Record';
    openTab(null, tab);

    // --- AJAX Customer Search Logic ---
    const searchInput = document.getElementById('customer_search');
    const resultsContainer = document.getElementById('search_results');
    const hiddenInput = document.getElementById('selected_customer_id');
    const selectionDisplay = document.getElementById('customer_selection_display');
    let debounceTimer;

    searchInput.addEventListener('input', function() {
        const query = this.value;
        selectionDisplay.innerHTML = '';
        selectionDisplay.style.display = 'none';
        hiddenInput.value = '';

        clearTimeout(debounceTimer);
        if (query.length < 2) {
            resultsContainer.innerHTML = '';
            resultsContainer.style.display = 'none';
            return;
        }

        debounceTimer = setTimeout(() => {
            fetch(`actions/search_customers.php?q=${encodeURIComponent(query)}`)
                .then(response => response.json())
                .then(data => {
                    resultsContainer.innerHTML = '';
                    if (data.length > 0) {
                        data.forEach(customer => {
                            const item = document.createElement('div');
                            item.className = 'result-item';
                            item.innerHTML = `<strong>${customer.name}</strong> (${customer.phone_number || 'No Phone'}) <span class="balance">Balance: ${customer.credit_balance}</span>`;
                            item.dataset.id = customer.id;
                            item.dataset.name = customer.name;
                            resultsContainer.appendChild(item);
                        });
                        resultsContainer.style.display = 'block';
                    } else {
                        resultsContainer.innerHTML = '<div class="result-item-none">No customers found.</div>';
                        resultsContainer.style.display = 'block';
                    }
                }).catch(err => console.error(err));
        }, 300);
    });

    resultsContainer.addEventListener('click', function(e) {
        const selectedItem = e.target.closest('.result-item');
        if (selectedItem) {
            hiddenInput.value = selectedItem.dataset.id;
            selectionDisplay.innerHTML = `Selected Customer: <strong>${selectedItem.dataset.name}</strong>`;
            selectionDisplay.style.display = 'block';
            searchInput.value = '';
            resultsContainer.innerHTML = '';
            resultsContainer.style.display = 'none';
        }
    });

    document.addEventListener('click', function(e) {
        if (!searchInput.contains(e.target) && !resultsContainer.contains(e.target)) {
            resultsContainer.style.display = 'none';
        }
    });
});
</script>

<?php include 'includes/footer.php'; ?>